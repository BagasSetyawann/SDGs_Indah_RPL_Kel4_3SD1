/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package example.indah.types;

import lombok.Data;

/**
 *
 * @author chand
 */
@Data
public class Login {
    private String username;
    private String password;
}
