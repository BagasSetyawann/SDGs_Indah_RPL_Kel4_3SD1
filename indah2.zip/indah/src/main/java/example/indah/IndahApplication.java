package example.indah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndahApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndahApplication.class, args);
	}

}
