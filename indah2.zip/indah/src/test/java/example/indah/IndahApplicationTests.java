package example.indah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndahApplicationTests {

	@Test
	void contextLoads() {
	}

}
